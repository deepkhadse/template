document.getElementById("submit").addEventListener("click", function () {
    const occasion = document.getElementById("occasion").value;
    if (occasion !== "") {
        window.location.href = occasion;
    }
});
